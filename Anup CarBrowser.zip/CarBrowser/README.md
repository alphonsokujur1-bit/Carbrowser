# Car Browser — a simple web browser for Android Auto

Works on Android 8.0 to Android 15 phones, including **Android 14**.

## What it does
- Shows full web pages on the car screen
- Buttons along the top: **Back, Forward, Reload, Address/Search**
- Buttons on the side: **Pan** (drag to scroll), **Page up, Page down, Home**
- Tap links on the car touchscreen, drag to scroll, pinch to zoom
- Quick links: Google, YouTube, Google News, Wikipedia
- Phone app settings: home page, and "Desktop mode" for full websites

## 1. Build the APK (one-time, on a computer)
1. Install **Android Studio** (free) from developer.android.com/studio.
2. Unzip this folder, then in Android Studio choose **File → Open** and pick the `CarBrowser` folder.
3. Wait for the "Gradle sync" to finish (the first time needs internet and takes 5–10 minutes).
   If Android Studio offers to upgrade the Gradle plugin, click **Upgrade**.
4. Choose **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
5. Click **locate** in the pop-up. The file is `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to your phone (WhatsApp to yourself, a USB cable or Google Drive).

## 2. Install on the phone
1. Open the APK on the phone and allow "Install unknown apps" when asked.
2. Open **Car Browser** once on the phone (you can set your home page here).

## 3. Make Android Auto show it
Android Auto hides apps that aren't from the Play Store, so:
1. Open **Android Auto settings** on the phone (Settings → Connected devices →
   Connection preferences → Android Auto).
2. Scroll down and tap **Version** about 10 times, then confirm to turn on developer mode.
3. Tap the **⋮** menu → **Developer settings** → turn on **Unknown sources**.
4. Back in Android Auto settings → **Customize launcher** → make sure **Car Browser** is ticked.
5. Connect to the car. Car Browser appears in the app list.

If it still doesn't appear, install the APK with **KingInstaller** or **AAAD**
instead of opening it directly. These tools make Android Auto treat the app as if it came from the Play Store.

## Notes and limits
- **Use only while parked.** Android Auto turns off the keyboard while you're driving.
- Tapping links needs a recent Android Auto version. If taps don't work, keep
  Android Auto updated from the Play Store.
- Netflix, Prime Video and similar sites may block video playback (DRM).
- Settings changes apply the next time you open Car Browser in the car.

## Files
- `CarBrowserService.kt`: entry point for Android Auto
- `BrowserScreen.kt`: car buttons
- `UrlScreen.kt`: address bar and quick links
- `WebRenderer.kt`: draws the web page on the car screen and passes touch input to it
- `WebPresentation.kt`: the WebView itself
- `MainActivity.kt`: phone settings screen
