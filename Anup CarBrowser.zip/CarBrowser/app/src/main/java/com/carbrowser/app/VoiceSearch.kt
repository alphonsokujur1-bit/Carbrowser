package com.carbrowser.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Listens once through the microphone and returns what was said. */
class VoiceSearch(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null

    fun hasMicPermission(): Boolean =
        context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED

    fun start(language: String, onResult: (String) -> Unit, onError: (String) -> Unit) {
        if (!hasMicPermission()) {
            onError("Mic not allowed. Open Car Browser on your phone and tap Allow microphone.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Voice recognition is not available on this phone")
            return
        }
        stop()

        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                stop()
                if (text.isNullOrBlank()) onError("Didn't catch that. Try again.")
                else onResult(text)
            }

            override fun onError(error: Int) {
                stop()
                onError(errorMessage(error))
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        r.startListening(intent)
    }

    fun stop() {
        recognizer?.destroy()
        recognizer = null
    }

    private fun errorMessage(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH,
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Didn't catch that. Try again."
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "No internet for voice search"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
            "Mic not allowed. Open Car Browser on your phone and tap Allow microphone."
        SpeechRecognizer.ERROR_AUDIO -> "Microphone problem (error $code)"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice search is busy. Try again."
        else -> "Voice search failed (error $code)"
    }
}
