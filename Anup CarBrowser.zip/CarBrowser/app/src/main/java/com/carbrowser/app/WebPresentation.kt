package com.carbrowser.app

import android.annotation.SuppressLint
import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.os.Bundle
import android.view.Display
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/** A window shown on the car's virtual display that holds the WebView. */
class WebPresentation(
    outerContext: Context,
    display: Display,
    private val startUrl: String,
    private val desktopMode: Boolean
) : Presentation(outerContext, display) {

    private var root: FrameLayout? = null
    private var webView: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val web = WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            if (desktopMode) settings.userAgentString = DESKTOP_USER_AGENT
            setBackgroundColor(Color.BLACK)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    // Keep http/https inside the browser; ignore app links (intent:, market:, etc.)
                    val scheme = request.url.scheme ?: return true
                    return scheme != "http" && scheme != "https"
                }
            }
            webChromeClient = WebChromeClient()
        }

        val container = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
            addView(
                web,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }

        root = container
        webView = web
        setContentView(container)
        web.loadUrl(startUrl)
    }

    /** Keeps the page inside the area not covered by Android Auto's own UI. */
    fun applyContentArea(area: Rect, width: Int, height: Int) {
        root?.setPadding(
            area.left.coerceAtLeast(0),
            area.top.coerceAtLeast(0),
            (width - area.right).coerceAtLeast(0),
            (height - area.bottom).coerceAtLeast(0)
        )
    }

    fun web(): WebView? = webView

    fun currentUrl(): String? = webView?.url

    fun destroyWeb() {
        webView?.apply {
            stopLoading()
            destroy()
        }
        webView = null
    }

    companion object {
        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
    }
}
