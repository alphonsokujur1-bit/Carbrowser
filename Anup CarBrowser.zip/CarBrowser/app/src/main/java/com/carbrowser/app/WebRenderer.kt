package com.carbrowser.app

import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import androidx.car.app.CarContext
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer

/**
 * Draws a real WebView onto the car screen.
 *
 * Android Auto gives us a drawing surface (because we register as a
 * navigation-style app). We create a private virtual display on that surface
 * and show a [WebPresentation] containing the WebView on it. Taps, drags and
 * pinches from the car screen are forwarded to the WebView.
 */
class WebRenderer(private val carContext: CarContext) : SurfaceCallback {

    private val prefs = Prefs(carContext)
    private var virtualDisplay: VirtualDisplay? = null
    private var presentation: WebPresentation? = null
    private var lastUrl: String = prefs.homePage
    private var surfaceWidth = 0
    private var surfaceHeight = 0
    private var stableArea: Rect? = null

    // ---- Surface lifecycle -------------------------------------------------

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        val surface = surfaceContainer.surface ?: return
        teardown()

        surfaceWidth = surfaceContainer.width
        surfaceHeight = surfaceContainer.height

        val dm = carContext.getSystemService(DisplayManager::class.java)
        val vd = dm.createVirtualDisplay(
            "CarBrowser",
            surfaceWidth,
            surfaceHeight,
            surfaceContainer.dpi,
            surface,
            0
        )
        virtualDisplay = vd

        presentation = WebPresentation(carContext, vd.display, lastUrl, prefs.desktopMode).also {
            it.show()
            stableArea?.let { area -> it.applyContentArea(area, surfaceWidth, surfaceHeight) }
        }
    }

    override fun onStableAreaChanged(stableArea: Rect) {
        this.stableArea = Rect(stableArea)
        presentation?.applyContentArea(stableArea, surfaceWidth, surfaceHeight)
    }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        teardown()
    }

    fun release() = teardown()

    private fun teardown() {
        presentation?.let { p ->
            p.currentUrl()?.let { lastUrl = it }
            p.destroyWeb()
            p.dismiss()
        }
        presentation = null
        virtualDisplay?.release()
        virtualDisplay = null
    }

    // ---- Touch input from the car screen -----------------------------------

    override fun onClick(x: Float, y: Float) {
        val target = presentation?.window?.decorView ?: return
        val t = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0)
        val up = MotionEvent.obtain(t, t + 60, MotionEvent.ACTION_UP, x, y, 0)
        down.source = InputDevice.SOURCE_TOUCHSCREEN
        up.source = InputDevice.SOURCE_TOUCHSCREEN
        target.dispatchTouchEvent(down)
        target.dispatchTouchEvent(up)
        down.recycle()
        up.recycle()
    }

    override fun onScroll(distanceX: Float, distanceY: Float) {
        presentation?.web()?.scrollBy(distanceX.toInt(), distanceY.toInt())
    }

    override fun onFling(velocityX: Float, velocityY: Float) {
        presentation?.web()?.flingScroll(-velocityX.toInt(), -velocityY.toInt())
    }

    override fun onScale(focusX: Float, focusY: Float, scaleFactor: Float) {
        val web = presentation?.web() ?: return
        if (scaleFactor < 0f) {
            web.zoomIn() // double-tap
        } else {
            web.zoomBy(scaleFactor.coerceIn(0.5f, 2.0f))
        }
    }

    // ---- Browser commands (buttons) ----------------------------------------

    fun currentUrl(): String? = presentation?.currentUrl() ?: lastUrl

    fun goBack() {
        presentation?.web()?.let { if (it.canGoBack()) it.goBack() }
    }

    fun goForward() {
        presentation?.web()?.let { if (it.canGoForward()) it.goForward() }
    }

    fun reload() {
        presentation?.web()?.reload()
    }

    fun pageUp() {
        presentation?.web()?.pageUp(false)
    }

    fun pageDown() {
        presentation?.web()?.pageDown(false)
    }

    fun goHome() = load(prefs.homePage)

    fun load(input: String) {
        val url = toUrl(input)
        lastUrl = url
        presentation?.web()?.loadUrl(url)
    }

    companion object {
        /** Turns "google.com" into a URL and "weather pune" into a Google search. */
        fun toUrl(input: String): String {
            val text = input.trim()
            return when {
                text.startsWith("http://") || text.startsWith("https://") -> text
                !text.contains(' ') && text.contains('.') -> "https://$text"
                else -> "https://www.google.com/search?q=" +
                        java.net.URLEncoder.encode(text, "UTF-8")
            }
        }
    }
}
