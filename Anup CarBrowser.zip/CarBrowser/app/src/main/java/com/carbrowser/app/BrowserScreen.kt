package com.carbrowser.app

import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

/**
 * Main car screen. The web page fills the background (drawn by [WebRenderer]);
 * this template only adds the buttons on top.
 *
 * Top strip  : Back (also exits fullscreen video), Mic (voice search), Reload, Address
 * Side strip : Pan (drag to scroll), Page up, Page down, Home
 */
class BrowserScreen(
    carContext: CarContext,
    private val renderer: WebRenderer
) : Screen(carContext) {

    private val prefs = Prefs(carContext)
    private val voice = VoiceSearch(carContext)

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) = voice.stop()
        })
    }

    override fun onGetTemplate(): Template {
        val actionStrip = ActionStrip.Builder()
            .addAction(iconAction(R.drawable.ic_back) { renderer.goBack() })
            .addAction(iconAction(R.drawable.ic_mic) { startVoiceSearch() })
            .addAction(iconAction(R.drawable.ic_reload) { renderer.reload() })
            .addAction(iconAction(R.drawable.ic_search) {
                screenManager.push(
                    UrlScreen(
                        carContext,
                        renderer.currentUrl(),
                        onOpen = { input -> renderer.load(input) },
                        onVoice = { startVoiceSearch() },
                        onForward = { renderer.goForward() }
                    )
                )
            })
            .build()

        val mapStrip = ActionStrip.Builder()
            .addAction(Action.PAN)
            .addAction(iconAction(R.drawable.ic_up) { renderer.pageUp() })
            .addAction(iconAction(R.drawable.ic_down) { renderer.pageDown() })
            .addAction(iconAction(R.drawable.ic_home) { renderer.goHome() })
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(actionStrip)
            .setMapActionStrip(mapStrip)
            .setPanModeListener { /* scrolling goes to the page */ }
            .build()
    }

    private fun startVoiceSearch() {
        toast("Listening… speak now")
        voice.start(
            prefs.voiceLanguage,
            onResult = { text ->
                toast("Searching: $text")
                renderer.search(text)
            },
            onError = { message -> toast(message) }
        )
    }

    private fun toast(message: String) {
        CarToast.makeText(carContext, message, CarToast.LENGTH_LONG).show()
    }

    private fun iconAction(iconRes: Int, onClick: () -> Unit): Action =
        Action.Builder()
            .setIcon(CarIcon.Builder(IconCompat.createWithResource(carContext, iconRes)).build())
            .setOnClickListener { onClick() }
            .build()
}
