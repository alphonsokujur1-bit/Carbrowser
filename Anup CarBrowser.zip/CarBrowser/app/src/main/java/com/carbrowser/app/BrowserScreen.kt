package com.carbrowser.app

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.graphics.drawable.IconCompat

/**
 * Main car screen. The web page fills the background (drawn by [WebRenderer]);
 * this template only adds the buttons on top.
 *
 * Top-right strip : Back, Forward, Reload, Address/Search
 * Side strip      : Pan (drag to scroll), Page up, Page down, Home
 */
class BrowserScreen(
    carContext: CarContext,
    private val renderer: WebRenderer
) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        val actionStrip = ActionStrip.Builder()
            .addAction(iconAction(R.drawable.ic_back) { renderer.goBack() })
            .addAction(iconAction(R.drawable.ic_forward) { renderer.goForward() })
            .addAction(iconAction(R.drawable.ic_reload) { renderer.reload() })
            .addAction(iconAction(R.drawable.ic_search) {
                screenManager.push(UrlScreen(carContext, renderer.currentUrl()) { input ->
                    renderer.load(input)
                })
            })
            .build()

        val mapStrip = ActionStrip.Builder()
            .addAction(Action.PAN)
            .addAction(iconAction(R.drawable.ic_up) { renderer.pageUp() })
            .addAction(iconAction(R.drawable.ic_down) { renderer.pageDown() })
            .addAction(iconAction(R.drawable.ic_home) { renderer.goHome() })
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(actionStrip)
            .setMapActionStrip(mapStrip)
            .setPanModeListener { /* nothing to change; scrolling goes to the page */ }
            .build()
    }

    private fun iconAction(iconRes: Int, onClick: () -> Unit): Action =
        Action.Builder()
            .setIcon(CarIcon.Builder(IconCompat.createWithResource(carContext, iconRes)).build())
            .setOnClickListener { onClick() }
            .build()
}
