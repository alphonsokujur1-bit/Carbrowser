package com.carbrowser.app

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ItemList
import androidx.car.app.model.Row
import androidx.car.app.model.SearchTemplate
import androidx.car.app.model.Template

/**
 * Address bar: type a website or search words with the car keyboard,
 * use voice search, or pick a quick link. (Android Auto allows typing only while parked.)
 */
class UrlScreen(
    carContext: CarContext,
    private val currentUrl: String?,
    private val onOpen: (String) -> Unit,
    private val onVoice: () -> Unit,
    private val onForward: () -> Unit
) : Screen(carContext) {

    private val quickLinks = listOf(
        "Google" to "https://www.google.com",
        "YouTube" to "https://m.youtube.com",
        "Google News" to "https://news.google.com",
        "Wikipedia" to "https://www.wikipedia.org"
    )

    override fun onGetTemplate(): Template {
        val list = ItemList.Builder()
            .addItem(
                Row.Builder()
                    .setTitle("🎤 Voice search")
                    .addText("Tap and speak")
                    .setOnClickListener {
                        screenManager.pop()
                        onVoice()
                    }
                    .build()
            )
            .addItem(
                Row.Builder()
                    .setTitle("→ Forward")
                    .addText("Go to the next page")
                    .setOnClickListener {
                        screenManager.pop()
                        onForward()
                    }
                    .build()
            )

        quickLinks.forEach { (name, url) ->
            list.addItem(
                Row.Builder()
                    .setTitle(name)
                    .addText(url)
                    .setOnClickListener { open(url) }
                    .build()
            )
        }

        return SearchTemplate.Builder(object : SearchTemplate.SearchCallback {
            override fun onSearchSubmitted(searchText: String) {
                if (searchText.isNotBlank()) open(searchText)
            }
        })
            .setHeaderAction(Action.BACK)
            .setSearchHint("Type a website or search")
            .setInitialSearchText(currentUrl ?: "")
            .setShowKeyboardByDefault(false)
            .setItemList(list.build())
            .build()
    }

    private fun open(input: String) {
        onOpen(input)
        screenManager.pop()
    }
}
