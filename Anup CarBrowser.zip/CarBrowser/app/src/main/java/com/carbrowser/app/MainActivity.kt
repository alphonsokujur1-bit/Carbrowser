package com.carbrowser.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Phone-side settings screen. The browser itself opens in Android Auto. */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var micStatus: TextView
    private lateinit var micButton: Button

    private val languages = listOf(
        "English (India)" to "en-IN",
        "हिन्दी (Hindi)" to "hi-IN",
        "मराठी (Marathi)" to "mr-IN"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val pad = (20 * resources.displayMetrics.density).toInt()

        fun heading(text: String) = TextView(this).apply {
            this.text = text
            textSize = 18f
            setPadding(0, pad, 0, pad / 4)
        }

        val title = TextView(this).apply {
            text = getString(R.string.app_name) + "  v1.1"
            textSize = 26f
        }
        val info = TextView(this).apply {
            text = "Connect your phone to the car and open \"Car Browser\" from the " +
                    "Android Auto app list.\n\nUse only while parked."
            textSize = 15f
        }

        // ---- Browsing ----
        val homeInput = EditText(this).apply {
            setText(prefs.homePage)
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            isSingleLine = true
        }
        val desktop = CheckBox(this).apply {
            text = "Desktop mode (request full websites)"
            isChecked = prefs.desktopMode
        }
        val fullScreen = CheckBox(this).apply {
            text = "Use the whole car screen (pages go behind the buttons)"
            isChecked = prefs.fullCarScreen
        }

        // ---- Microphone ----
        micStatus = TextView(this).apply { textSize = 15f }
        micButton = Button(this).apply {
            setOnClickListener {
                if (hasMic()) openAppSettings()
                else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            }
        }
        val micSites = CheckBox(this).apply {
            text = "Let websites use the microphone"
            isChecked = prefs.micForWebsites
        }
        val langGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        languages.forEachIndexed { i, (name, code) ->
            langGroup.addView(RadioButton(this).apply {
                id = 1000 + i
                text = name
                isChecked = prefs.voiceLanguage == code
            })
        }
        if (langGroup.checkedRadioButtonId == -1) langGroup.check(1000)

        val save = Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.homePage = WebRenderer.toUrl(
                    homeInput.text.toString().ifBlank { Prefs.DEFAULT_HOME })
                prefs.desktopMode = desktop.isChecked
                prefs.fullCarScreen = fullScreen.isChecked
                prefs.micForWebsites = micSites.isChecked
                val idx = (langGroup.checkedRadioButtonId - 1000).coerceIn(0, languages.lastIndex)
                prefs.voiceLanguage = languages[idx].second
                homeInput.setText(prefs.homePage)
                Toast.makeText(this@MainActivity,
                    "Saved. Reopen Car Browser in the car to apply.", Toast.LENGTH_LONG).show()
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad * 2)
            addView(title)
            addView(info)
            addView(heading("Home page"))
            addView(homeInput)
            addView(desktop)
            addView(fullScreen)
            addView(heading("Microphone"))
            addView(micStatus)
            addView(micButton)
            addView(micSites)
            addView(heading("Voice search language"))
            addView(langGroup)
            addView(heading(""))
            addView(save)
        }
        setContentView(ScrollView(this).apply { addView(layout) })
        refreshMic()
    }

    override fun onResume() {
        super.onResume()
        if (::micStatus.isInitialized) refreshMic()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            refreshMic()
            if (!hasMic()) {
                Toast.makeText(this, "Mic blocked. Allow it in App settings → Permissions.",
                    Toast.LENGTH_LONG).show()
                openAppSettings()
            }
        }
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun refreshMic() {
        if (hasMic()) {
            micStatus.text = "✅ Microphone allowed. The 🎤 button works in the car."
            micButton.text = "Microphone settings"
        } else {
            micStatus.text = "❌ Microphone not allowed yet."
            micButton.text = "Allow microphone"
        }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", packageName, null)))
    }

    companion object {
        private const val REQ_MIC = 1
    }
}
