package com.carbrowser.app

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Phone-side settings screen. The browser itself opens in Android Auto. */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 26f
        }
        val info = TextView(this).apply {
            text = "Connect your phone to the car and open \"Car Browser\" from the " +
                    "Android Auto app list.\n\nUse only while parked.\n"
            textSize = 15f
        }
        val homeLabel = TextView(this).apply { text = "Home page"; textSize = 16f }
        val homeInput = EditText(this).apply {
            setText(prefs.homePage)
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            isSingleLine = true
        }
        val desktop = CheckBox(this).apply {
            text = "Desktop mode (request full websites)"
            isChecked = prefs.desktopMode
        }
        val save = Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.homePage = WebRenderer.toUrl(homeInput.text.toString().ifBlank { Prefs.DEFAULT_HOME })
                prefs.desktopMode = desktop.isChecked
                homeInput.setText(prefs.homePage)
                Toast.makeText(this@MainActivity,
                    "Saved. Reopen Car Browser in the car to apply.", Toast.LENGTH_LONG).show()
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            addView(title)
            addView(info)
            addView(homeLabel)
            addView(homeInput)
            addView(desktop)
            addView(save)
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
