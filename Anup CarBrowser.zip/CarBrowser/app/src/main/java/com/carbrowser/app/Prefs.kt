package com.carbrowser.app

import android.content.Context

/** Small settings store shared by the phone screen and the car screen. */
class Prefs(context: Context) {

    private val sp = context.getSharedPreferences("car_browser", Context.MODE_PRIVATE)

    var homePage: String
        get() = sp.getString(KEY_HOME, DEFAULT_HOME) ?: DEFAULT_HOME
        set(value) = sp.edit().putString(KEY_HOME, value).apply()

    var desktopMode: Boolean
        get() = sp.getBoolean(KEY_DESKTOP, false)
        set(value) = sp.edit().putBoolean(KEY_DESKTOP, value).apply()

    /** Let websites (e.g. Google, meeting sites) use the microphone. */
    var micForWebsites: Boolean
        get() = sp.getBoolean(KEY_MIC_SITES, true)
        set(value) = sp.edit().putBoolean(KEY_MIC_SITES, value).apply()

    /** Language for the mic (voice search) button, e.g. "en-IN", "hi-IN", "mr-IN". */
    var voiceLanguage: String
        get() = sp.getString(KEY_VOICE_LANG, "en-IN") ?: "en-IN"
        set(value) = sp.edit().putString(KEY_VOICE_LANG, value).apply()

    /** Draw pages on the whole car screen, including behind the buttons. */
    var fullCarScreen: Boolean
        get() = sp.getBoolean(KEY_FULL_SCREEN, false)
        set(value) = sp.edit().putBoolean(KEY_FULL_SCREEN, value).apply()

    companion object {
        private const val KEY_HOME = "home_page"
        private const val KEY_DESKTOP = "desktop_mode"
        private const val KEY_MIC_SITES = "mic_websites"
        private const val KEY_VOICE_LANG = "voice_language"
        private const val KEY_FULL_SCREEN = "full_car_screen"
        const val DEFAULT_HOME = "https://www.google.com"
    }
}
