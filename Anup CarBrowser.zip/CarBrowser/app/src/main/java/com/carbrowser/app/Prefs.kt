package com.carbrowser.app

import android.content.Context

/** Small settings store shared by the phone screen and the car screen. */
class Prefs(context: Context) {

    private val sp = context.getSharedPreferences("car_browser", Context.MODE_PRIVATE)

    var homePage: String
        get() = sp.getString(KEY_HOME, DEFAULT_HOME) ?: DEFAULT_HOME
        set(value) = sp.edit().putString(KEY_HOME, value).apply()

    var desktopMode: Boolean
        get() = sp.getBoolean(KEY_DESKTOP, false)
        set(value) = sp.edit().putBoolean(KEY_DESKTOP, value).apply()

    companion object {
        private const val KEY_HOME = "home_page"
        private const val KEY_DESKTOP = "desktop_mode"
        const val DEFAULT_HOME = "https://www.google.com"
    }
}
